package ProvaMerge;

public class MainClass {

    public static void main(String[] args) {
        //Activitat Control versions 2
        
        System.out.println("A");
        
        System.out.println("B");
        
        System.out.println("C");
    }
    
}
